import os

path=os.getenv("Path")
MY_DB_URL=os.getenv("MY_DB_URL")
print(path)

print(MY_DB_URL)