from pydantic import BaseModel, EmailStr,ConfigDict
from datetime import datetime
from typing import  Optional  

#creating/sending class-to server
class PostBase(BaseModel):
        title: str
        content: str
        published: bool = True   

class PostCreate(PostBase):
        pass
     
#response/results class-from server     
class PostResp(PostBase): 
        id: int
        created_at: datetime
        
        model_config = ConfigDict(from_attributes=True)
            
#creating/sending class-to server            
class UserCreate(BaseModel):
        email: EmailStr
        password: str  
        
class UserLogin(BaseModel):
        email: EmailStr
        password: str  
 
class Token(BaseModel):
        access_token: str
        token_type: str


class TokenData(BaseModel):
        id: Optional[str] = None
        
#response/results class-from server 
class UserResp(BaseModel):
        id: int 
        email: EmailStr 
        created_at: datetime  

        model_config = ConfigDict(from_attributes=True) 
        

class UserLogin(BaseModel):
        email: EmailStr
        password: str  

class Token(BaseModel):
        access_token: str
        token_type: str


class TokenData(BaseModel):
        id: Optional[str]  = None 