from fastapi import Response, status, HTTPException, Depends, APIRouter
from .. import models, database, schemas,oauth2
from typing import List
 
router= APIRouter(
            prefix="/posts", 
            tags=["Posts"]) 

@router.get("/",response_model=List[schemas.PostResp])
def get_posts(db: database.Session = Depends(database.get_db),user_id: int =Depends(oauth2.get_current_user)):
    print("get all posts")  
    posts=db.query(models.cPost).all() 
    return posts
  
@router.get("/{id}",response_model=schemas.PostResp)
def get_post(id: int,db: database.Session = Depends(database.get_db),user_id: int =Depends(oauth2.get_current_user)): 
    print("get post by id ")   
    posts=db.query(models.cPost).filter(models.cPost.id == id).first()  
    
    if not posts:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"post with id: {id} was not found")
    
    return posts

 
@router.post("/", status_code=status.HTTP_201_CREATED,response_model=schemas.PostResp)
def create_posts(npost: schemas.PostCreate,db: database.Session = Depends(database.get_db),user_id: int =Depends(oauth2.get_current_user)):   
    print("ïnsert new post")   
    print(user_id)
    posts=models.cPost(**npost.dict()) 
    
    db.add(posts)
    db.commit()
    db.refresh(posts) 
    return posts

@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_post(id: int,db: database.Session = Depends(database.get_db),user_id: int =Depends(oauth2.get_current_user)):  
    print("delete post")  
    posts=db.query(models.cPost).filter(models.cPost.id == id) 
    
    if not posts.first():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"post with id: {id} was not found")
     
    posts.delete(synchronize_session=False) 
    db.commit()  
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.put("/{id}",response_model=schemas.PostResp)
def update_post(id: int, upost: schemas.PostCreate,db: database.Session = Depends(database.get_db),user_id: int =Depends(oauth2.get_current_user)):   
    print("update post")  
    
    post_query=db.query(models.cPost).filter(models.cPost.id == id) 
    posts=post_query.first()
    
    if not posts:
       raise HTTPException (status_code= status.HTTP_404_NOT_FOUND,
                           detail = f'post with id : {id} does not exist')
 
    post_query.update(upost.dict(),synchronize_session=False) 
    db.commit()  
    return post_query.first()
 